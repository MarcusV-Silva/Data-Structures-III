#ifndef FUNCIONALIDADES_H
#define FUNCIONALIDADES_H

// Bibliotecas da linguagem C usadas no trabalho
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Funcionalidades do trabalho
void funcionalidade8();
void funcionalidade9();
void funcionalidade10();
void funcionalidade11();
void funcionalidade12();

#endif
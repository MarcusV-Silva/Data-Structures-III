#ifndef FUNCIONALIDADES_H
#define FUNCIONALIDADES_H

// Bibliotecas da linguagem C usadas no trabalho
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Funcionalidades do trabalho
void funcionalidade1();
void funcionalidade2();
void funcionalidade3(FILE *binFile,char *tmp1, char *tmp2);
void funcionalidade4(FILE *binFile, int *RRN);
void funcionalidade5();
void funcionalidade6();
void funcionalidade7();

#endif
#ifndef FUNCIONALIDADES_H
#define FUNCIONALIDADES_H

// Bibliotecas da linguagem C usadas no trabalho
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Funcionalidades do trabalho
void funcionalidade1();
void funcionalidade2();
void funcionalidade3();
void funcionalidade4();
void funcionalidade5();
void funcionalidade6();
void funcionalidade7();

#endif